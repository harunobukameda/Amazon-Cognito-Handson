const signUp = (username, password, email, customAttr, callback) => {
    const attributeList = [];
    attributeList.push(
        new AWSCognito.
            CognitoIdentityServiceProvider.
            CognitoUserAttribute({
                Name : 'custom:attr',
                Value : customAttr
            }
        )
    );
    attributeList.push(
        new AWSCognito.
            CognitoIdentityServiceProvider.
            CognitoUserAttribute({
                Name : 'email',
                Value : email
            }
        )
    );
    
    TargetUserPool.signUp(username, password, attributeList, null,
        (err, result) => {
        
            if (err) {
                alert(err);
                callback(err, result);
                return;
            }

            const cognitoUser = result.user;
            const signUpResult = {
                username: cognitoUser.getUsername()
            };
            callback(err, signUpResult);
        }
    );
};

const activate = (username, verificationCode, callback) => {
    const cognitoUser = new AWSCognito.
                        CognitoIdentityServiceProvider.CognitoUser({
        Username : username,
        Pool : TargetUserPool
    });

    cognitoUser.confirmRegistration(verificationCode, true, 
        (err, result) => {

            if (err) {
                alert(err);
                callback(err, result);
                return;
            }
            console.log("Activation result:", result);

            callback(err, result);
        }
    );
};

const signIn = (username, password, callbacks) => {
    const authenticationDetails = new AWSCognito.
            CognitoIdentityServiceProvider.AuthenticationDetails({
        Username : username,
        Password : password
    });

    const cognitoUser = new AWSCognito.
            CognitoIdentityServiceProvider.CognitoUser({
        Username : username,
        Pool : TargetUserPool
    });

    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: (result) => {
            console.log("Sign-in result:");
            console.dir(result);
            callbacks.onSuccess(result);
        },
        onFailure: (err) => {
            alert(err);
            callbacks.onFailure(err);
        }
    }); 
}

const callPublicAPI = () => {
    const ajax = (callback) => {
        const endpoint = HandsonConfig.apiGWEndpoint + "/public";    
        $.ajax({
            type: "GET",
            url: endpoint,
            contentType: "application/json",
            complete: (xhr, status) => {
                console.log("Response:", xhr);
                const responseSummary = 
                    "Response status code: " + xhr.status + "\n" +
                    "Response status text: " + xhr.statusText + "\n" + 
                    "(" + AWS.util.date.iso8601(new Date) + ")";
                callback(responseSummary);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (callback) => {ajax(callback)}
    };
};

const callPrivateAPI = () => {
    const ajax = (callback) => {
        const endpoint = HandsonConfig.apiGWEndpoint + "/private/1";    
        $.ajax({
            type: "GET",
            url: endpoint,
            contentType: "application/json",
            complete: (xhr, status) => {
                console.log("Response:", xhr);
                const responseSummary = 
                    "Response status code: " + xhr.status + "\n" +
                    "Response status text: " + xhr.statusText + "\n" + 
                    "(" + AWS.util.date.iso8601(new Date) + ")";
                callback(responseSummary);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (callback) => {ajax(callback)}
    };
};