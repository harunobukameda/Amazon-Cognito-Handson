/**
 * TODO: Fix these values 
 */
const HandsonConfig = {
    region: 'ap-northeast-1',

    // User Pool
    userPoolId: 'ap-northeast-1_xxxxxxxxx',
    appClientId: 'XXXXXXXXXXXXXXXXXXXXXXXXXXX',

    // Federated Identity
    identityPoolId: 'ap-northeast-1:XXXXXXXXXXXXXXXXXXXXXXXXXXX' ,

    // API Gateway
    apiGWEndpoint: 'https://XXXXXXXXX.execute-api.ap-northeast-1.amazonaws.com/XXXXXXX',

    // S3
    s3BucketName: 'XXXXXXXXXXXXXXXXXXXXXXXXXXX'
}