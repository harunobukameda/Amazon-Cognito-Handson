(() => {
    if (!SignInStatus.lastIdentityToken) {
        return;
    }

    const providerName = "cognito-idp." + HandsonConfig.region + ".amazonaws.com/" + HandsonConfig.userPoolId;
    const logins = {};
    logins[providerName] = SignInStatus.lastIdentityToken;
    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        IdentityPoolId: HandsonConfig.identityPoolId,
        Logins: logins
    });
    AWS.config.credentials.get((err) => {
        if (err) {
            console.error(err);
        } else {
            console.log("AWS credentials by Cognito Identity:", AWS.config.credentials);
            $('#identity-id').val(AWS.config.credentials.identityId);
        }
    });
})();

const callPublicAPI = () => {
    const ajax = (callback) => {
        const endpoint = HandsonConfig.apiGWEndpoint + "/public";
        $.ajax({
            type: "GET",
            url: endpoint,
            contentType: "application/json",
            complete: (xhr, status) => {
                console.log("Response:", xhr);
                const responseSummary =
                    "Response status code: " + xhr.status + "\n" +
                    "Response status text: " + xhr.statusText + "\n" +
                    "(" + AWS.util.date.iso8601(new Date) + ")";
                callback(responseSummary);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (callback) => { ajax(callback) }
    };
};

const callPrivate1API = () => {
    const ajax = (callback) => {
        const apigClient = apigClientFactory.newClient({
            accessKey: AWS.config.credentials.accessKeyId,
            secretKey: AWS.config.credentials.secretAccessKey,
            sessionToken: AWS.config.credentials.sessionToken,
            region: HandsonConfig.region
        });
        apigClient.private1Get({}, {}, {})
            .then((res) => {
                res = "Response status code: " + res.status + "\n" +
                    "Response status text: " + res.data + "\n" +
                    "(" + AWS.util.date.iso8601(new Date) + ")";
                callback(res);
            }).catch((res) => {
                console.error(res);
                callback("Error: "
                    + TargetUserPool.getCurrentUser().getUsername()
                    + " couldn't call this API!");
            });
    };

    return {
        code: ajax.toString(),
        call: (callback) => { ajax(callback) }
    };
};

const callPrivate2API = () => {
    const ajax = (callback) => {
        const apigClient = apigClientFactory.newClient({
            accessKey: AWS.config.credentials.accessKeyId,
            secretKey: AWS.config.credentials.secretAccessKey,
            sessionToken: AWS.config.credentials.sessionToken,
            region: HandsonConfig.region
        });
        apigClient.private2Get({}, {}, {})
            .then((res) => {
                res = "Response status code: " + res.status + "\n" +
                    "Response status text: " + res.data + "\n" +
                    "(" + AWS.util.date.iso8601(new Date) + ")";
                callback(res);
            }).catch((res) => {
                console.error(res);
                callback("Error: "
                    + TargetUserPool.getCurrentUser().getUsername()
                    + " couldn't call this API!");
            });
    };

    return {
        code: ajax.toString(),
        call: (callback) => { ajax(callback) }
    };
};

const callS3ListAPI = () => {
    const ajax = (bucketName, identityID, callback) => {
        const params = {
            Bucket: bucketName,
            Prefix: identityID + "/"
        };
        console.dir(params);
        const s3 = new AWS.S3();
        s3.listObjectsV2(params, (err, data) => {
            if (err) {
                console.log(err, err.stack);
                callback(err);
            } else {
                console.log(data);
                const contents = data.Contents.map((c) => {return c.Key});
                callback(contents);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (b, i, callback) => { ajax(b, i, callback) }
    };
};

const callS3PutAPI = () => {
    const ajax = (bucketName, identityID, file, callback) => {
        const params = {
            Body: file,
            ContentType: file.type,
            Bucket: bucketName,
            Key: identityID + "/" + file.name
        };
        console.dir(params);
        const s3 = new AWS.S3();
        s3.putObject(params, (err, data) => {
            if (err) {
                console.log(err, err.stack);
                callback(err);
            } else {
                console.log(data);
                callback(data);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (b, i, f, callback) => { ajax(b, i, f, callback) }
    };
};

const callS3GetAPI = () => {
    const ajax = (bucketName, identityID, objectName, callback) => {
        const params = {
            Bucket: bucketName,
            Key: identityID + "/" + objectName
        };
        console.dir(params);
        const s3 = new AWS.S3();
        s3.getObject(params, (err, data) => {
            if (err) {
                console.log(err, err.stack);
                callback(err);
            } else {
                console.log(data);
                callback(data);
            }
        });
    };

    return {
        code: ajax.toString(),
        call: (b, i, o, callback) => { ajax(b, i, o, callback) }
    };
};
