AWS.config.region = HandsonConfig.region;
AWSCognito.config.region = HandsonConfig.region;

const TargetUserPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool({ 
    UserPoolId: HandsonConfig.userPoolId,
    ClientId: HandsonConfig.appClientId 
});

/**
 * Confirm sign-in status
 */
const SignInStatus = {
    currentCognitoUser: TargetUserPool.getCurrentUser(),
    lastIdentityToken: null,
    lastAccessToken: null
};

(() => {
    const currentPage = location.pathname.substr(location.pathname.lastIndexOf('/') + 1); 
    if (!SignInStatus.currentCognitoUser) {
        console.log("Not logged in.");
        if (currentPage == 'mypage.html') {
            $(location).attr('href', 'index.html');
        }
        return null;
    }
    SignInStatus.currentCognitoUser.getSession((err, session) => {
        if (err) {
            SignInStatus.currentCognitoUser.clearCachedTokens();
            SignInStatus.lastIdentityToken = null;
            SignInStatus.lastAccessToken = null;
            SignInStatus.currentCognitoUser = null;
            return;
        }
        SignInStatus.lastIdentityToken = session.getIdToken().getJwtToken();
        SignInStatus.lastAccessToken = session.getAccessToken().getJwtToken();
        if (SignInStatus.lastIdentityToken) {
            if (currentPage == 'index.html') {
                $(location).attr('href', 'mypage.html');
            }
        }
    });
})();

/**
 * Utilities
 */
const lockForm = (form, lock) => {
    form.find(':input, button').attr('disabled', lock);
};

const clearForm = (form) => {
    form.find('input').val('');
};

const updateTextArea = (textArea, newValue) => {
    textArea.val(newValue);
    textArea.attr('rows', textArea.val().split("\n").length);
}

const prettyResult = (resultObj) => {
    return '(' + (new Date).toString() + ')\n--------------\n' + JSON.stringify(resultObj, null, '  ');
};
